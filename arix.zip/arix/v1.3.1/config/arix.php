<?php

return [

    /* LOGO */
    'logo' => '/arix/Arix.png', // Panel logo
    'fullLogo' => false, // Logo only (Enable or disable the text next to the panel logo.)
    'logoHeight' => '32px', // Panel Logo Height

    /* SOCIALS */
    'discord' => '715281172422197300', // Discord ID (Leave empty remove the discord link from your panel)
    'support' => 'https://discord.gg/geCjrRbAwC', // Leave empty to remove the support link from your panel
    'status' => 'https://status.weijers.one', // Leave empty to remove the support link from your panel
    'billing' => 'https://billing.weijers.one', // Leave empty to remove the support link from your panel

    'announcementType' => 'party', // Available Types: disabled, update, info, success, alert, warning.
    'announcementCloseable' => false, // Closable announcement
    'announcementMessage' => 'Welcome to Arix, the worst Pterodactyl Theme', // Announcement message (For styling use BBCode format.)

    /* MAIL */
    'mail_color' => '#4a35cf',
    'mail_backgroundColor' => '#F5F5FF',
    'mail_logo' => 'https://arix.gg/arix.png',
    'mail_logoFull' => false,
    'mail_mode' => 'light',

    'mail_discord' => 'https://arix.gg/discord',
    'mail_twitter' => 'https://x.com',
    'mail_facebook' => 'https://facebook.com',
    'mail_instagram' => 'https://instagram.com',
    'mail_linkedin' => 'https://linkedin.com',
    'mail_youtube' => 'https://youtube.com',

    'mail_status' => 'https://arix.gg/status',
    'mail_billing' => 'https://arix.gg/billing',
    'mail_support' => 'https://arix.gg/support',

    /* COMPONENTS */
    'serverRow' => 1, // Server Row Card (Types: 1,2,3)
    'socialButtons' => false,
    'discordBox' => true,

    'statsCards' => 1, // Types: 1,2,3
    'sideGraphs' => 2, // Types: 1,2,3
    'graphs' => 2, // Types 1,2,3

    'slot1' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced
    'slot2' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced
    'slot3' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced
    'slot4' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced
    'slot5' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced
    'slot6' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced
    'slot7' => 'disabled', // Types: disabled, banner, statCards, graphs, sideGraphs, SFTP, info, infoAdvanced

    /* LAYOUT */
    'layout' => 1, // 1,2,3,4,5
    'searchComponent' => 1, // 1,2
    'logoPosition' => 1, // 1,2
    'socialPosition' => 1, // 1,2
    'loginLayout' => 1, // 1,2,3,4

    /* STYLING */
    'backgroundImage' => 'none', // Use path
    'backgroundImageLight' => 'none', // Use path
    'backdrop' => false,
    'backdropPercentage' => '100%',
    'defaultMode' => 'darkmode',
    'copyright' => 'Designed by Weijers.one',
    'radiusInput' => '7px',
    'borderInput' => true,
    'radiusBox' => '10px',
    'flashMessage' => 1,
    'pageTitle' => true,
    'loginBackground' => '/arix/background-login.png',
    'loginGradient' => false,

    /* META */
    'meta_color' => '#4a35cf',
    'meta_title' => 'Pterodactyl Panel',
    'meta_description' => 'Our official Pterodactyl panel',
    'meta_image' => '/arix/meta-tags.png',
    'meta_favicon' => '/arix/Arix.png',

    /* ADVANCED */
    'font' => 'Roboto',
    'profileType' => 'gravatar',
    'modeToggler' => true,
    'langSwitch' => true,
    'ipFlag' => true,
    'lowResourcesAlert' => false,

    /* COLORS */
    'primary' => '#4A35CF',

    'successText' => '#E1FFD8',
    'successBorder' => '#56AA2B',
    'successBackground' => '#3D8F1F',

    'dangerText' => '#FFD8D8',
    'dangerBorder' => '#AA2A2A',
    'dangerBackground' => '#8F1F20',

    'secondaryText' => '#B2B2C1',
    'secondaryBorder' => '#42425B',
    'secondaryBackground' => '#2B2B40',

    'gray50' => '#F4F4F4',
    'gray100' => '#D5D5DB',
    'gray200' => '#B2B2C1',
    'gray300' => '#8282A4',
    'gray400' => '#5E5E7F',
    'gray500' => '#42425B',
    'gray600' => '#2B2B40',
    'gray700' => '#1D1D37',
    'gray800' => '#0B0D2A',
    'gray900' => '#040519',

    /* LIGHT MODE COLORS */
    'lightmode_primary' => '#4A35CF',

    'lightmode_successText' => '#E1FFD8',
    'lightmode_successBorder' => '#56AA2B',
    'lightmode_successBackground' => '#3D8F1F',

    'lightmode_dangerText' => '#FFD8D8',
    'lightmode_dangerBorder' => '#AA2A2A',
    'lightmode_dangerBackground' => '#8F1F20',

    'lightmode_secondaryText' => '#46464D',
    'lightmode_secondaryBorder' => '#C0C0D3',
    'lightmode_secondaryBackground' => '#A6A7BD',

    'lightmode_gray50' => '#141415',
    'lightmode_gray100' => '#27272C',
    'lightmode_gray200' => '#46464D',
    'lightmode_gray300' => '#626272',
    'lightmode_gray400' => '#757689',
    'lightmode_gray500' => '#A6A7BD',
    'lightmode_gray600' => '#C0C0D3',
    'lightmode_gray700' => '#E7E7EF',
    'lightmode_gray800' => '#F0F1F5',
    'lightmode_gray900' => '#FFFFFF',

];